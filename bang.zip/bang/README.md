# call-sms
git clone https://github.com/kongpun1/call-sms
cd call-sms
php a.php [ใส่เบอร์ที่ต้องการยิง เช่น 0123456789 ไม่ต้องเปลี่ยน0เป็น66]
[เลือกว่าจะยิงอะไรเช่น SMS CALL ALL ]
ตัวอย่าง php a.php 0123456789 ALL

